import {  useEffect } from "react"
import { useLocation } from "react-router-dom"
import Navbar from "../Views/Navbar"
import Footer from "../Views/Footer"
export default function Layout({children}:{children: React.ReactNode}) {
    const location=useLocation()
    useEffect(() => {
        window.scrollTo(0, 0)
       
    }, [location.pathname])

  return (
    <div className="min-h-[100vh] bg-white">
      <Navbar/>
      {children}
      <Footer/>

    </div>
  )
}
