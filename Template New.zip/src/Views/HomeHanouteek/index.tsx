import Categories from "./Categories";
import Products from "./Products";


export default function HomeHanouteek() {
  return (
    <div>
      <Categories/>
      <Products/>
    </div>
  )
}
