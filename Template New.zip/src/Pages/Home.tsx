import { useSelector } from "react-redux";
// import Container from "../Views/Container";
// import HomeHanouteek from "../Views/HomeHanouteek";
import { ThemeSetting } from "../Types/ThemeSetting";

import SectionRoot from "../Views/Sections/SectionRoot";

export default function Home() {
  const theme = useSelector<ThemeSetting>((state) => state.theme) as ThemeSetting


  return (
    <>
      {/* <Container>
        <HomeHanouteek />
      </Container> */}

      {
        theme.theme.HomePage.HomePageSections.map((el,k)=>{
          el.type
          return <SectionRoot data={el} key={el.type+k}/>
        })
      }
    </>
  )
}
