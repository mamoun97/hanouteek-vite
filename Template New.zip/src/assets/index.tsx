import img_dz from "./dz.svg"
import img_en from "./us.svg"
import img_fr from "./fr.svg"
import an from "./an.svg"
import offrebg from "./offrebg.svg"
import loginBackground from "./loginBackground.webp"
import waslet from "./waslet.png"

const images = {
    img_dz,
    img_en,
    img_fr,an,offrebg,
    loginBackground,
    waslet
}
export default images