

export const Classes = {
    input: `
        block p-2.5 w-full text-base text-gray-900 bg-gray-50 focus:border-1 
        rounded-lg border !shadow-none border-gray-300 outline-none  focus:ring-0
        focus:border-primary focus:border-2 font-semibold
    `
}
