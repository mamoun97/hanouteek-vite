interface CustomInput {
    id?: string,
    label: string,
    isValid?: boolean,
    inputClassName?:string,
    isError?: string | null,
}